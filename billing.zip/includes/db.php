<?php
$host = "localhost";
$user = "primaria_test";
$password = "Olympics@2028";
$database = "primaria_test";

$conn = new mysqli($host, $user, $password, $database);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
?>

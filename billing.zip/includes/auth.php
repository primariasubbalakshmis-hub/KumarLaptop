<?php
session_start();
include 'db.php';

$username = $_POST['username'];
$password = $_POST['password'];

// Prepare and execute query
$stmt = $conn->prepare("SELECT * FROM users WHERE username = ? AND password = ?");
$stmt->bind_param("ss", $username, $password);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows === 1) {
    $user = $result->fetch_assoc();
    $_SESSION['username'] = $user['username'];
    $_SESSION['role'] = $user['role']; // admin or staff

    // ✅ Correct redirect to dashboard (outside /includes/)
    header("Location: ../dashboard.php");
    exit();
} else {
    $_SESSION['error'] = "Invalid username or password";

    // ✅ Correct redirect back to login (outside /includes/)
    header("Location: ../index.php");
    exit();
}
?>

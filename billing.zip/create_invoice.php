<?php
session_start();
include 'includes/db.php';

if (!isset($_SESSION['username'])) {
  header("Location: index.php");
  exit();
}

$username = $_SESSION['username'] ?? 'unknown';

// Handle Form Submission
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
  $customer_name = $_POST['customer_name'];
  $department = $_POST['department'];
  $service_description = $_POST['service_description'];
  $service_charge = $_POST['service_charge'];
  $payment_mode = $_POST['payment_mode'];
  $remarks = $_POST['remarks'];

  $sql = "INSERT INTO invoices (customer_name, department, service_description, service_charge, payment_mode, remarks, created_by)
          VALUES (?, ?, ?, ?, ?, ?, ?)";

  $stmt = $conn->prepare($sql);
  $stmt->bind_param("sssssss", $customer_name, $department, $service_description, $service_charge, $payment_mode, $remarks, $username);
  $stmt->execute();

  if ($stmt->affected_rows > 0) {
    $invoice_id = $stmt->insert_id;
    header("Location: print_invoice.php?id=$invoice_id");
    exit();
  } else {
    $error = "Failed to save invoice.";
  }
}
?>

<!DOCTYPE html>
<html>
<head>
  <title>Create Invoice - Primaria</title>
  <style>
    body {
      font-family: 'Segoe UI', sans-serif;
      background: #f4f6f9;
      margin: 0;
      padding: 0;
    }

    .container {
      width: 95%;
      max-width: 600px;
      margin: 30px auto;
      background: #fff;
      padding: 25px;
      border-radius: 10px;
      box-shadow: 0 0 15px rgba(0,0,0,0.1);
    }

    h2 {
      text-align: center;
      color: #0d2d75;
      margin-bottom: 20px;
    }

    label {
      font-weight: bold;
      display: block;
      margin-top: 15px;
    }

    input, select, textarea {
      width: 100%;
      padding: 10px;
      margin-top: 5px;
      border-radius: 5px;
      border: 1px solid #ccc;
    }

    .btn-row {
      margin-top: 20px;
      display: flex;
      justify-content: space-between;
    }

    .btn {
      padding: 10px 20px;
      border: none;
      border-radius: 5px;
      font-weight: bold;
      cursor: pointer;
    }

    .btn-primary {
      background-color: #0d2d75;
      color: white;
    }

    .btn-danger {
      background-color: #dc3545;
      color: white;
    }

    .error {
      color: red;
      margin-top: 15px;
      text-align: center;
    }
  </style>
</head>
<body>

<div class="container">
  <h2>Create New Invoice</h2>
  
  <?php if (isset($error)): ?>
    <div class="error"><?= $error ?></div>
  <?php endif; ?>

  <form method="POST">
    <label>Customer Name:</label>
    <input type="text" name="customer_name" required>

    <label>Department:</label>
    <select name="department" required>
      <option value="">-- Select Department --</option>
      <option value="Home Health">Home Health</option>
      <option value="MedTech">MedTech</option>
      <option value="Dental">Dental</option>
      <option value="Care & Diagnosis">Care & Diagnosis</option>
      <option value="IT">IT</option>
    </select>

    <label>Service Description:</label>
    <textarea name="service_description" required></textarea>

    <label>Service Charge (₹):</label>
    <input type="number" name="service_charge" step="0.01" required>

    <label>Payment Mode:</label>
    <select name="payment_mode" required>
      <option value="Cash">Cash</option>
      <option value="UPI">UPI</option>
      <option value="Card">Card</option>
      <option value="Bank Transfer">Bank Transfer</option>
    </select>

    <label>Remarks:</label>
    <textarea name="remarks"></textarea>

    <div class="btn-row">
      <button type="reset" class="btn btn-danger">Cancel</button>
      <button type="submit" class="btn btn-primary">Save & Print</button>
    </div>
  </form>
</div>

</body>
</html>

<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);

session_start();
include 'includes/db.php';

// Redirect to login if not logged in
if (!isset($_SESSION['username'])) {
  header("Location: index.php");
  exit();
}

// Fetch invoices
$sql = "SELECT * FROM invoices ORDER BY id DESC";
$result = $conn->query($sql);
?>

<!DOCTYPE html>
<html>
<head>
  <title>View Invoices</title>
  <style>
    body {
      font-family: Arial, sans-serif;
      background: #f4f6f9;
      margin: 0;
      padding: 0;
    }

    .container {
      width: 95%;
      margin: 30px auto;
      background: #fff;
      padding: 20px;
      border-radius: 10px;
      box-shadow: 0 0 10px rgba(0,0,0,0.1);
      overflow-x: auto;
    }

    h2 {
      text-align: center;
      color: #0d2d75;
    }

    table {
      width: 100%;
      border-collapse: collapse;
      margin-top: 20px;
      font-size: 14px;
    }

    th, td {
      border: 1px solid #ccc;
      padding: 10px;
      text-align: left;
    }

    th {
      background-color: #0d2d75;
      color: white;
    }

    tr:nth-child(even) {
      background-color: #f9f9f9;
    }

    .back-btn {
      display: inline-block;
      padding: 8px 15px;
      background-color: #0d2d75;
      color: white;
      text-decoration: none;
      border-radius: 5px;
      margin-bottom: 10px;
    }

    .back-btn:hover {
      background-color: #0b2260;
    }
  </style>
</head>
<body>
  <div class="container">
    <h2>All Invoices</h2>
    <a class="back-btn" href="create_invoice.php">+ Create New Invoice</a>

    <?php if ($result->num_rows > 0): ?>
    <table>
      <tr>
        <th>ID</th>
        <th>Customer Name</th>
        <th>Department</th>
        <th>Service Description</th>
        <th>Service Charge (₹)</th>
        <th>Payment Mode</th>
        <th>Remarks</th>
        <th>Created By</th>
        <th>Created At</th>
      </tr>
      <?php while($row = $result->fetch_assoc()): ?>
      <tr>
        <td><?= $row['id'] ?></td>
        <td><?= htmlspecialchars($row['customer_name']) ?></td>
        <td><?= htmlspecialchars($row['department']) ?></td>
        <td><?= htmlspecialchars($row['service_description']) ?></td>
        <td>₹<?= htmlspecialchars($row['service_charge']) ?></td>
        <td><?= htmlspecialchars($row['payment_mode']) ?></td>
        <td><?= htmlspecialchars($row['remarks']) ?></td>
        <td><?= htmlspecialchars($row['created_by']) ?></td>
        <td><?= $row['created_at'] ?? '-' ?></td>
      </tr>
      <?php endwhile; ?>
    </table>
    <?php else: ?>
      <p>No invoices found.</p>
    <?php endif; ?>
  </div>
</body>
</html>

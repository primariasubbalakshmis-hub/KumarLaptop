<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);
session_start();
include 'includes/db.php';

if (!isset($_GET['id'])) {
  echo "Invalid Request";
  exit();
}

$id = intval($_GET['id']);
$sql = "SELECT * FROM invoices WHERE id = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $id);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows == 0) {
  echo "Invoice not found";
  exit();
}

$invoice = $result->fetch_assoc();
$services = json_decode($invoice['service_json'], true);
?>
<!DOCTYPE html>
<html>
<head>
  <title>Invoice #<?= $invoice['id'] ?></title>
  <style>
    body { font-family: Arial, sans-serif; margin: 40px; }
    .header { text-align: center; border-bottom: 2px solid #000; padding-bottom: 10px; margin-bottom: 30px; }
    .logo { max-height: 80px; }
    .invoice-details { margin-bottom: 30px; }
    .invoice-details strong { display: inline-block; width: 160px; }
    table { width: 100%; border-collapse: collapse; margin-bottom: 30px; }
    th, td { border: 1px solid #999; padding: 10px; text-align: left; }
    th { background: #0d2d75; color: white; }
    .total-line td { font-weight: bold; text-align: right; }
    .footer { text-align: center; font-size: 14px; color: #777; }
    @media print {
      button { display: none; }
    }
  </style>
</head>
<body>
  <div class="header">
    <img src="assets/logo.png" alt="Company Logo" class="logo">
    <h2>Primaria Healthcare</h2>
    <p>Official Invoice</p>
  </div>

  <div class="invoice-details">
    <p><strong>Invoice ID:</strong> <?= $invoice['id'] ?></p>
    <p><strong>Customer Name:</strong> <?= htmlspecialchars($invoice['customer_name']) ?></p>
    <p><strong>Department:</strong> <?= htmlspecialchars($invoice['department']) ?></p>
    <p><strong>Payment Mode:</strong> <?= $invoice['payment_mode'] ?></p>
    <p><strong>Remarks:</strong> <?= $invoice['remarks'] ?></p>
    <p><strong>Created By:</strong> <?= $invoice['created_by'] ?> on <?= $invoice['created_at'] ?></p>
  </div>

  <table>
    <tr>
      <th>#</th>
      <th>Product</th>
      <th>Qty</th>
      <th>Amount</th>
      <th>Total</th>
    </tr>
    <?php $i = 1; $subtotal = 0;
    foreach ($services as $service): 
      $line_total = $service['qty'] * $service['amount'];
      $subtotal += $line_total;
    ?>
      <tr>
        <td><?= $i++ ?></td>
        <td><?= htmlspecialchars($service['product']) ?></td>
        <td><?= $service['qty'] ?></td>
        <td>₹<?= number_format($service['amount'], 2) ?></td>
        <td>₹<?= number_format($line_total, 2) ?></td>
      </tr>
    <?php endforeach; ?>

    <tr class="total-line">
      <td colspan="4">Subtotal</td>
      <td>₹<?= number_format($invoice['total_amount'], 2) ?></td>
    </tr>
    <tr class="total-line">
      <td colspan="4">GST (<?= $invoice['gst_type'] === 'with' ? '18%' : '0%' ?>)</td>
      <td>₹<?= number_format($invoice['gst_amount'], 2) ?></td>
    </tr>
    <tr class="total-line">
      <td colspan="4">Final Amount</td>
      <td>₹<?= number_format($invoice['final_amount'], 2) ?></td>
    </tr>
  </table>

  <div class="footer">
    <p>Thank you for choosing Primaria Healthcare</p>
    <p>Authorized Signatory: ____________________</p>
  </div>

  <button onclick="window.print()">🖨️ Print Invoice</button>
  <button onclick="window.location.href='dashboard.php'">⬅️ Back to Dashboard</button>
</body>
</html>

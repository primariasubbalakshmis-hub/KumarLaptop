<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);
session_start();
include 'includes/db.php';

$username = $_SESSION['username'] ?? null;
$role = $_SESSION['role'] ?? null;

// --- Handle Form Submit ---
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['customer_name'])) {
  $customer_name = $_POST['customer_name'];
  $department = $_POST['department'];
  $payment_mode = $_POST['payment_mode'];
  $remarks = $_POST['remarks'];
  $gst_type = $_POST['gst_type'] ?? 'without';
  $created_by = $username;

  $services = $_POST['services'];
  $total = 0;
  foreach ($services as $s) {
    $qty = floatval($s['qty']);
    $amt = floatval($s['amount']);
    $total += $qty * $amt;
  }
  $gst_amount = ($gst_type === 'with') ? $total * 0.18 : 0;
  $final_amount = $total + $gst_amount;

  $service_json = json_encode($services);
  $sql = "INSERT INTO invoices (customer_name, department, payment_mode, remarks, created_by, service_json, total_amount, gst_type, gst_amount, final_amount)
          VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
  $stmt = $conn->prepare($sql);
  $stmt->bind_param("ssssssddsd", $customer_name, $department, $payment_mode, $remarks, $created_by, $service_json, $total, $gst_type, $gst_amount, $final_amount);
  $stmt->execute();

  $invoice_id = $stmt->insert_id;
  header("Location: print_invoice.php?id=$invoice_id");
  exit();
}

// --- Fetch Invoices ---
if ($role === 'staff') {
  $stmt = $conn->prepare("SELECT * FROM invoices WHERE created_by = ? ORDER BY id DESC");
  $stmt->bind_param("s", $username);
} else {
  $stmt = $conn->prepare("SELECT * FROM invoices ORDER BY id DESC");
}
$stmt->execute();
$result = $stmt->get_result();
?>
<!DOCTYPE html>
<html>
<head>
  <title>Dashboard - Primaria</title>
  <style>
    body { font-family: Arial, sans-serif; margin: 0; padding: 0; background: #f4f6f9; }
    header { background: #0d2d75; color: white; padding: 10px 20px; display: flex; align-items: center; }
    header img { height: 50px; margin-right: 15px; }
    .container { display: flex; }
    .sidebar { width: 200px; background: #0d2d75; color: white; min-height: 100vh; padding-top: 30px; }
    .sidebar button, .sidebar a { display: block; width: 100%; padding: 15px; background: none; border: none; text-align: left; color: white; cursor: pointer; }
    .content { flex: 1; padding: 30px; }
    .btn { padding: 8px 16px; border: none; border-radius: 5px; cursor: pointer; }
    .btn-danger { background: #dc3545; color: white; }
    h2 { color: #0d2d75; }
    label { font-weight: bold; display: block; margin-top: 10px; }
    input, select, textarea { width: 100%; padding: 8px; margin-top: 5px; border-radius: 5px; border: 1px solid #ccc; }
    table.service-table, .service-table th, .service-table td { border: 1px solid #ccc; border-collapse: collapse; padding: 8px; text-align: left; }
    .service-table th { background: #f0f0f0; }
    .service-table input { width: 100%; }
    table.invoice-table { width: 100%; border-collapse: collapse; margin-top: 20px; }
    .invoice-table th, .invoice-table td { border: 1px solid #ccc; padding: 10px; text-align: left; }
    .invoice-table th { background: #0d2d75; color: white; }
  </style>
</head>
<body>
<header>
  <img src="assets/logo.png" alt="Logo">
  <h1>Primaria Billing Dashboard</h1>
</header>
<div class="container">
  <div class="sidebar">
    <button onclick="showSection('createForm')">📝 Create Invoice</button>
    <button onclick="showSection('viewInvoices')">📄 View Invoices</button>
    <a href="logout.php" class="btn btn-danger">🚪 Logout</a>
  </div>
  <div class="content">
    <h2>Welcome, <?= htmlspecialchars($username) ?> (<?= $role ?>)</h2>

    <div id="createForm" style="display:none;">
      <h2>Create Invoice</h2>
      <form method="POST">
        <label>Customer Name:</label>
        <input type="text" name="customer_name" required>

        <label>Department:</label>
        <select name="department" required>
          <option value="">Select Department</option>
          <option value="Home Health">Home Health</option>
          <option value="MedTech">MedTech</option>
          <option value="Dental">Dental</option>
          <option value="Care & Diagnosis">Care & Diagnosis</option>
          <option value="IT">IT</option>
        </select>

        <label>Payment Mode:</label>
        <select name="payment_mode" required>
          <option value="Cash">Cash</option>
          <option value="UPI">UPI</option>
          <option value="Card">Card</option>
          <option value="Bank Transfer">Bank Transfer</option>
        </select>

        <label>Remarks:</label>
        <textarea name="remarks"></textarea>

        <label>GST:</label>
        <select name="gst_type" onchange="updateTotals()">
          <option value="without">Without GST</option>
          <option value="with">With GST (18%)</option>
        </select>

        <label>Service Description:</label>
        <table class="service-table">
          <thead>
            <tr><th>Product</th><th>Qty</th><th>Rate</th><th>Total</th></tr>
          </thead>
          <tbody id="services">
            <tr class="service-row">
              <td><input type="text" name="services[0][product]" required></td>
              <td><input type="number" name="services[0][qty]" required oninput="calculateRow(this)"></td>
              <td><input type="number" name="services[0][amount]" required oninput="calculateRow(this)"></td>
              <td><input type="text" name="services[0][total]" readonly></td>
            </tr>
          </tbody>
        </table>
        <button type="button" onclick="addService()">➕ Add Service</button>

        <label>Subtotal (₹):</label>
        <input type="text" id="subtotal" readonly>

        <label>GST (18%):</label>
        <input type="text" id="gst_amount" readonly>

        <label>Final Total:</label>
        <input type="text" id="final_total" readonly>

        <br><br>
        <button type="submit" class="btn btn-primary">💾 Save & Print</button>
      </form>
    </div>

    <div id="viewInvoices" style="display:none;">
      <h2>Invoices</h2>
      <?php if ($result->num_rows > 0): ?>
        <table class="invoice-table">
          <tr>
            <th>ID</th><th>Customer</th><th>Department</th><th>Mode</th><th>By</th><th>Final (₹)</th><th>Created At</th><th>Action</th>
          </tr>
          <?php while($row = $result->fetch_assoc()): ?>
          <tr>
            <td><?= $row['id'] ?></td>
            <td><?= htmlspecialchars($row['customer_name']) ?></td>
            <td><?= $row['department'] ?></td>
            <td><?= $row['payment_mode'] ?></td>
            <td><?= $row['created_by'] ?></td>
            <td>₹<?= number_format($row['final_amount'], 2) ?></td>
            <td><?= $row['created_at'] ?></td>
            <td><a href="print_invoice.php?id=<?= $row['id'] ?>">🖨️ Print</a></td>
          </tr>
          <?php endwhile; ?>
        </table>
      <?php else: ?>
        <p>No invoices found.</p>
      <?php endif; ?>
    </div>
  </div>
</div>
<script>
function showSection(sectionId) {
  const sections = ['createForm', 'viewInvoices'];
  sections.forEach(id => {
    const el = document.getElementById(id);
    if (el) el.style.display = 'none';
  });
  const activeSection = document.getElementById(sectionId);
  if (activeSection) activeSection.style.display = 'block';
}

let serviceIndex = 1;
function addService() {
  const services = document.getElementById('services');
  const tr = document.createElement('tr');
  tr.className = 'service-row';
  tr.innerHTML = `
    <td><input type="text" name="services[${serviceIndex}][product]" required></td>
    <td><input type="number" name="services[${serviceIndex}][qty]" required oninput="calculateRow(this)"></td>
    <td><input type="number" name="services[${serviceIndex}][amount]" required oninput="calculateRow(this)"></td>
    <td><input type="text" name="services[${serviceIndex}][total]" readonly></td>
  `;
  services.appendChild(tr);
  serviceIndex++;
}

function calculateRow(input) {
  const row = input.closest('tr');
  const qty = parseFloat(row.querySelector('[name*="[qty]"]').value) || 0;
  const rate = parseFloat(row.querySelector('[name*="[amount]"]').value) || 0;
  const total = qty * rate;
  row.querySelector('[name*="[total]"]').value = total.toFixed(2);
  updateTotals();
}

function updateTotals() {
  let subtotal = 0;
  document.querySelectorAll('.service-row').forEach(row => {
    const qty = parseFloat(row.querySelector('[name*="[qty]"]').value) || 0;
    const rate = parseFloat(row.querySelector('[name*="[amount]"]').value) || 0;
    subtotal += qty * rate;
  });

  const gstType = document.querySelector('[name="gst_type"]')?.value;
  const gst = (gstType === 'with') ? subtotal * 0.18 : 0;
  const final = subtotal + gst;

  document.getElementById('subtotal').value = subtotal.toFixed(2);
  document.getElementById('gst_amount').value = gst.toFixed(2);
  document.getElementById('final_total').value = final.toFixed(2);
}
</script>
</body>
</html>

<?php session_start(); ?>
<!DOCTYPE html>
<html>
<head>
  <title>Login - Billing Portal</title>
  <style>
    body {
      background: #f4f6f9;
      font-family: Arial, sans-serif;
    }
    .login-container {
      width: 300px;
      margin: 100px auto;
      background: white;
      padding: 20px;
      border-radius: 10px;
      box-shadow: 0 0 10px #ccc;
    }
    input[type="text"], input[type="password"] {
      width: 100%;
      padding: 10px;
      margin-bottom: 15px;
      border: 1px solid #aaa;
      border-radius: 5px;
    }
    button {
      width: 100%;
      padding: 10px;
      background: #0d2d75;
      color: white;
      border: none;
      border-radius: 5px;
    }
    .error {
      color: red;
      text-align: center;
    }
  </style>
</head>
<body>
  <div class="login-container">
    <h2 align="center">Primaria Billing Login</h2>
    
    <?php
      if (isset($_SESSION['error'])) {
        echo "<p class='error'>" . $_SESSION['error'] . "</p>";
        unset($_SESSION['error']);
      }
    ?>

    <!-- ✅ Corrected path to auth.php -->
    <form method="POST" action="includes/auth.php">
      <input type="text" name="username" placeholder="Username" required />
      <input type="password" name="password" placeholder="Password" required />
      <button type="submit">Login</button>
    </form>
  </div>
</body>
</html>
